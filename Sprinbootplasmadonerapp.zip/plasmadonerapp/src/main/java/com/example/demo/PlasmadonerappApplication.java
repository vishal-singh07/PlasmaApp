package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlasmadonerappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlasmadonerappApplication.class, args);
	}

}
