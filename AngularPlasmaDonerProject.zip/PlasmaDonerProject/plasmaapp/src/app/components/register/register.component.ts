import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(public http:HttpClient) { }

  ngOnInit(): void {
  }
  bloodgroups=["-select-","A+","A-","B+","B-","O+","O-","AB+","AB-"];
  var_name=""
  var_state=""
  var_bloodgroup=""
  var_phone=""
  var_city=""
  clickHandler(){
    var applicant={
      
      "name":this.var_name,
      "state":this.var_state,
      "bloodgroup":this.var_bloodgroup,
      "city":this.var_city,
      "phone":this.var_phone,
    }
    this.http.post<any>("http://localhost:8080/donors",applicant).subscribe(data=>{
      //this will contain response from server
      alert("Data sent successfully")
    });
  }
}
