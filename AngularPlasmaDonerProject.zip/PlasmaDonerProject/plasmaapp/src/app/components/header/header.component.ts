import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
 imgurl="https://post.healthline.com/wp-content/uploads/2020/03/Coronavirus_Illustration_1296x728-header.jpg";

}
