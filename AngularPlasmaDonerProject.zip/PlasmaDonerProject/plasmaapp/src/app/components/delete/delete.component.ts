import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(public http:HttpClient) { }

  ngOnInit(): void {
  }
  var_delete="";
  deleteHandler(){
    this.http.delete("http://localhost:8080/donors"+this.var_delete);
    alert("Deregistered Successfully")
  }

}
