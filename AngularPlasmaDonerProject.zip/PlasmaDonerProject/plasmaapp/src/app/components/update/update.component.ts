import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  constructor(public http:HttpClient) { }

  ngOnInit(): void {
  }
  var_oldphone=""
  
  bloodgroups=["-select-","A+","A-","B+","B-","O+","O-","AB+","AB-"];
  var_name=""
  var_state=""
  var_bloodgroup=""
  var_phone=""
  var_city=""

  updateHandler(){

    var applicant={
      
      "name":this.var_name,
      "state":this.var_state,
      "bloodgroup":this.var_bloodgroup,
      "city":this.var_city,
      "phone":this.var_phone,
    }
    this.http.put("http://localhost:8080/donors"+this.var_oldphone,applicant);
    alert("Updated")
  
  }
  

}
