import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {

  constructor(public http:HttpClient) { }

  ngOnInit(): void {
  }
  msg="";
  requestHandler(){
    this.http.get<any>("http://localhost:8080/donors").subscribe(data=>{
    for(var index in data){
      this.msg+="<b>Id  :</b>"+data[index].id+"<b> Name  :</b>"+data[index].name+"<b> State  :</b>"+data[index].state+
      "<b> City  :</b>"+data[index].city+"<b> Phone  :</b>"+data[index].phone+"<b> BloodGroup  :</b>"+data[index].bloodgroup+"<br>";
    }
  })


  }

}
